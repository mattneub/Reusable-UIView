//
//  ViewController.swift
//  ReusableUiView
//
//  Created by Taka on 22.12.19.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var contentView: ReusableUIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        addCardView(self)
    }
}

